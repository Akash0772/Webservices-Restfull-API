package com.akash.app4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App4Application {

	public static void main(String[] args) {
		SpringApplication.run(App4Application.class, args);
	}

}
