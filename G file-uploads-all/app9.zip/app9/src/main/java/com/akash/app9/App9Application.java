package com.akash.app9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App9Application {

	public static void main(String[] args) {
		SpringApplication.run(App9Application.class, args);
	}

}
