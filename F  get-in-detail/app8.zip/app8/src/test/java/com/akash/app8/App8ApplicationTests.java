package com.akash.app8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
