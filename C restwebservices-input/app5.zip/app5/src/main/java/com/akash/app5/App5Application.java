package com.akash.app5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App5Application {

	public static void main(String[] args) {
		SpringApplication.run(App5Application.class, args);
	}

}
