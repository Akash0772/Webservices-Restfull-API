package com.akash.app13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App13Application {

	public static void main(String[] args) {
		SpringApplication.run(App13Application.class, args);
	}

}
