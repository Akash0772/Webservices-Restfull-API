package com.akash.app11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
